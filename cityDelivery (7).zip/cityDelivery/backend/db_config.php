<?php

$hostname = 'localhost';
$username = 'root';
$password = '';
$db = 'CityDelivery';

?>